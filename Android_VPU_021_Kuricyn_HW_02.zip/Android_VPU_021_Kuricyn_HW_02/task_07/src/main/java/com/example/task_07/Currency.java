package com.example.task_07;

public class Currency {
    public String sCod;
    public String currencyName;

    public Currency(String sCod, String currencyName){
        this.sCod = sCod;
        this.currencyName = currencyName;
    }

}
